export default {
  globalData: { version: '0.2.0', language: 'ja' },
  onLaunch() {},
};
