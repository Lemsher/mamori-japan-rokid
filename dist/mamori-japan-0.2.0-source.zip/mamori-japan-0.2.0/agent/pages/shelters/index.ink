<script def>
{"navigationBarTitleText":"まもり / 避難先"}
</script>
<script setup>
import wx from 'wx';
import {handleKeys,methodActions} from '../../modules/keys.js';
import {requestPosition,locationError} from '../../modules/locations.js';
import {SHELTER_TYPES,nearbyShelters} from '../../modules/shelters.js';
import {watchRegion} from '../../modules/monitoring.js';
import {eventKey} from '../../modules/alerts.js';
export default {
 onKeyUp(e){handleKeys(this,e,methodActions(this,['back']).concat(this.data.types.map(item=>({id:'type-'+item.code,run:()=>this.type({currentTarget:{attributes:{'data-code':item.code}}})})),methodActions(this,this.data.hazard&&!this.data.busy?['search']:[]),this.data.places.map((item,index)=>({id:'place-'+index,run:()=>this.navigate({currentTarget:{attributes:{'data-id':item.id}}})}))),()=>wx.navigateBack());},
 data:{keyFocus:'',lang:'ja',hazard:'',types:[],places:[],message:'',busy:false,destination:null},
 t(ja,zh){return this.data.lang==='zh'?zh:ja;},
 onLoad(q={}){const lang=q.lang==='zh'?'zh':'ja';this.setData({lang,hazard:SHELTER_TYPES[q.hazard]?q.hazard:'',types:Object.entries(SHELTER_TYPES).map(([code,labels])=>({code,label:labels[lang==='zh'?1:0]}))});},
 onShow(){this._active=true;this._watch=watchRegion(()=>{},a=>wx.navigateTo({url:'/pages/alert/index?lang='+this.data.lang+'&key='+encodeURIComponent(eventKey(a))}));},
 type(e){this._generation=(this._generation||0)+1;this.setData({hazard:e.currentTarget.attributes['data-code'],places:[],destination:null,busy:false,message:''});},
 async search(){
  if(!this.data.hazard||this.data.busy)return;const generation=this._generation=(this._generation||0)+1;
  this.setData({busy:true,places:[],destination:null,message:this.t('現在地と避難場所を確認中','正在获取当前位置和避难地点')});
  try{const position=await requestPosition(typeof navigator==='undefined'?null:navigator.geolocation);if(position.accuracy>1000)throw new Error('location-inaccurate');const result=await nearbyShelters(position,this.data.hazard);if(!this._active||generation!==this._generation)return;
   this.setData({places:result.places.map(p=>({...p,elevation:Number.isFinite(p.elevationMeters)?this.t('地面標高 約 ','地面海拔约 ')+p.elevationMeters+' m':'',distance:p.distanceMeters>=1000?(p.distanceMeters/1000).toFixed(1)+' km':p.distanceMeters+' m'})),message:result.places.length?this.t('直線距離順。開設・経路の通行可否は未確認。','按直线距离排序；开放状态及道路可通行性未核实。'):this.t('対応する場所を取得できません。標識・自治体情報を確認。','未取得适合该灾种的地点，请按现场标识及当地政府信息行动。')});
  }catch(e){if(this._active&&generation===this._generation)this.setData({message:locationError(e,this.data.lang)});}finally{if(this._active&&generation===this._generation)this.setData({busy:false});}
 },
 navigate(e){const p=this.data.places.find(p=>p.id===e.currentTarget.attributes['data-id']);if(p)this.setData({destination:p,message:this.t('Hi Rokidのナビで目的地を指定。自動開始はこの宿主では未接続。','在 Hi Rokid 导航中指定该目的地。当前宿主尚未接通自动启动导航。')});},
 back(){wx.navigateBack();},
 onHide(){this._active=false;this._generation=(this._generation||0)+1;this._watch?.stop();},onUnload(){this.onHide();}
};
</script>
<page>
 <scroll-view class="panel" scroll-y="true" scroll-into-view="{{'nav-' + keyFocus}}">
  <view class="row"><button bindtap="back" id="{{'nav-' + ('back')}}">{{keyFocus === ('back') ? '▶ ' : ''}}←</button><text class="heading">{{lang === 'zh' ? '指定紧急避难场所' : '指定緊急避難場所'}}</text></view>
  <text class="note">{{lang === 'zh' ? '按实际灾种选择。GPS 坐标用于在线查询，不持久保存。' : '災害種別を選択。GPS座標はオンライン照会に使い、保存しません。'}}</text>
  <view class="types"><button ink:for="{{types}}" ink:key="code" data-code="{{item.code}}" bindtap="type" id="{{'nav-' + ('type-' + item.code)}}">{{keyFocus === ('type-' + item.code) ? '▶ ' : ''}}{{hazard === item.code ? '● ' : ''}}{{item.label}}</button></view>
  <button bindtap="search" disabled="{{busy || !hazard}}" id="{{'nav-' + ('search')}}">{{keyFocus === ('search') ? '▶ ' : ''}}{{busy ? (lang === 'zh' ? '查询中' : '確認中') : (lang === 'zh' ? 'GPS 查询附近' : 'GPSで周辺を検索')}}</button>
  <text class="note">{{message}}</text>
  <view class="place" ink:for="{{places}}" ink:key="id"><text class="name">{{item.name}}</text><text class="note">{{item.distance}} · {{item.address}}</text><text class="note">{{item.remarks}}</text><text class="note">{{item.elevation}}</text><button bindtap="navigate" data-id="{{item.id}}" id="{{'nav-' + ('place-' + index)}}">{{keyFocus === ('place-' + index) ? '▶ ' : ''}}{{lang === 'zh' ? '查看导航方式' : 'ナビの起動方法'}}</button></view>
  <view class="place" ink:if="{{destination}}"><text class="name">{{destination.name}}</text><text class="note">{{destination.address}}</text><text class="name">Hi Rokid, navigate to {{destination.name}} {{destination.address}}</text><text class="note">{{lang === 'zh' ? '核对目标名称与地址，选择步行；遇积水或封路立即停止前行。' : '目的地名・住所を確認し徒歩を選択。冠水や通行止めには進まない。'}}</text></view>
  <text class="note">{{lang === 'zh' ? '来源：国土地理院。海啸仅列津波适用场所；海拔高低不能单独证明安全。' : '出典：国土地理院。津波は対応場所のみ。標高だけで安全を判断しない。'}}</text>
 </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;padding:12px 16px;box-sizing:border-box;background:#000;color:var(--color-text-primary,#40ff5e);border:1px solid var(--color-primary,#40ff5e);border-radius:10px;}.row,.types{display:flex;flex-direction:row;align-items:center;gap:7px;}.types{flex-wrap:wrap;margin:8px 0;}.heading{font-size:19px;font-weight:700;}.note{display:block;font-size:12px;line-height:1.4;margin:6px 0;}.name{display:block;font-size:16px;font-weight:700;}.place{border-top:1px solid var(--color-primary,#40ff5e);padding-top:10px;margin-top:12px;}button{font-size:12px;padding:6px 8px;border:1px solid var(--color-primary,#40ff5e);border-radius:6px;background:#000;color:var(--color-primary,#40ff5e);}
</style>
