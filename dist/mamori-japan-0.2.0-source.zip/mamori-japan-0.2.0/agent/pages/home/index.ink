<script def>
{"navigationBarTitleText":"まもり"}
</script>
<script setup>
import wx from 'wx';
import {handleKeys,methodActions} from '../../modules/keys.js';
import {cityByCode,rememberCity,recalledCity,recalledCoast} from '../../modules/locations.js';
import {startTextInput} from '../../modules/text-input.js';
import {classifyIntent} from '../../modules/playbooks.js';
import {warningSummary,isSnapshotFresh,jstTime} from '../../modules/client.js';
import {cachedSnapshot,watchRegion,store} from '../../modules/monitoring.js';
import {eventKey} from '../../modules/alerts.js';
export default {
 onKeyUp(e){handleKeys(this,e,methodActions(this,['language','gps','listen','location','postal','alerts','refresh','earthquake','tsunami','landslide','flood','typhoon','volcano','prepare']),()=>wx.navigateBack());},
 data:{keyFocus:'',lang:'ja',city:'場所を設定 / 设置所在地',cityCode:'',forecast:'',summary:'',message:'',updated:'',coast:''},
 t(ja,zh){return this.data.lang==='zh'?zh:ja;},
 onLoad(q={}){
  const s=store(),city=cityByCode(q.cityCode)||recalledCity(s);if(city)rememberCity(city.code,s);
  this.setData({lang:q.lang==='zh'?'zh':q.lang==='ja'?'ja':s?.getItem('mamori-language')==='zh'?'zh':'ja',cityCode:city?.code||'',city:city?city.office+' '+city.name:'場所を設定 / 设置所在地',coast:recalledCoast(s)});
 },
 onShow(){this._active=true;const c=recalledCity(store());if(c)this.setData({cityCode:c.code,city:c.office+' '+c.name,coast:recalledCoast(store())});this.paint(cachedSnapshot());this._watch=watchRegion(s=>this.paint(s),a=>this.openAlert(a),()=>this.setData({summary:this.t('通信失敗・最新警報は未確認','连接失败，最新预警未确认')}));},
 paint(s){
  if(!s||s.city?.code!==this.data.cityCode){this.setData({forecast:'',summary:this.t('場所を確認すると天気と災害情報を取得','确认所在地后获取天气和灾害信息')});return;}
  const day=isSnapshotFresh(s)&&!s.forecast?.stale?s.forecast?.days?.[0]:null;
  this.setData({forecast:day?day.condition:this.t('天気は未確認','天气未确认'),summary:warningSummary(s,this.data.lang),updated:jstTime(s.checkedAt),message:s.errors?.some(e=>e.reason==='not-configured')?this.t('警報サービスは未接続。','预警服务尚未连接。'):''});
 },
 location(){wx.navigateTo({url:'/pages/location/index?lang='+this.data.lang});},
 gps(){wx.navigateTo({url:'/pages/location/index?lang='+this.data.lang+'&action=locate'});},
 postal(){wx.navigateTo({url:'/pages/location/index?lang='+this.data.lang+'&action=postal'});},
 listen(){if(this._recognition)this._recognition.abort();this.setData({message:this.t('住所・郵便番号・状況を話す / Studio右側に入力','请说出地址、邮编或情况；也可在 Studio 右侧输入')});this._recognition=startTextInput(text=>this.ask(text),()=>this.setData({message:this.t('音声入力を開始できません。地域一覧を使用。','语音输入不可用，请使用地区列表。')}),()=>{this._recognition=null;});},
 onVoiceWakeup(){this.listen();},
 async ask(text){
  const intent=classifyIntent(text);if(intent.intent!=='unknown'&&intent.intent!=='weather'){this.guide(intent.intent,intent.blocked);return;}
  if(intent.intent==='weather'){this.refresh();return;}
  wx.navigateTo({url:'/pages/location/index?lang='+this.data.lang+'&query='+encodeURIComponent(text)});
 },
 refresh(){this.setData({message:this.t('更新中','正在更新')});this._watch?.refresh();},
 language(){const lang=this.data.lang==='ja'?'zh':'ja';this.setData({lang});try{store()?.setItem('mamori-language',lang);}catch{}this.paint(cachedSnapshot());},
 openAlert(a){wx.navigateTo({url:'/pages/alert/index?lang='+this.data.lang+(a?'&key='+encodeURIComponent(eventKey(a)):'')});},
 alerts(){this.openAlert();},
 guide(hazard,blocked=false){wx.navigateTo({url:'/pages/guide/index?hazard='+hazard+'&lang='+this.data.lang+'&blocked='+blocked});},
 earthquake(){this.guide('earthquake');},tsunami(){this.guide('tsunami');},landslide(){this.guide('landslide');},flood(){this.guide('flood');},typhoon(){this.guide('typhoon');},volcano(){this.guide('volcano');},prepare(){this.guide('prepare');},
 onHide(){this._active=false;this._watch?.stop();if(this._recognition)this._recognition.abort();},onUnload(){this.onHide();}
};
</script>
<page>
 <scroll-view class="panel" scroll-y="true" scroll-into-view="{{'nav-' + keyFocus}}">
  <view class="row top"><text class="brand">まもり</text><text class="minor">ROKID GLASSES · v0.2.0</text><button bindtap="language" id="{{'nav-' + ('language')}}">{{keyFocus === ('language') ? '▶ ' : ''}}{{lang === 'zh' ? '中文' : '日本語'}}</button></view>
  <text class="place">{{city}}</text>
  <view class="row"><button bindtap="gps" id="{{'nav-' + ('gps')}}">{{keyFocus === ('gps') ? '▶ ' : ''}}GPS</button><button bindtap="listen" id="{{'nav-' + ('listen')}}">{{keyFocus === ('listen') ? '▶ ' : ''}}{{lang === 'zh' ? '语音/地址' : '音声・住所'}}</button><button bindtap="location" id="{{'nav-' + ('location')}}">{{keyFocus === ('location') ? '▶ ' : ''}}{{lang === 'zh' ? '地区列表' : '地域一覧'}}</button><button bindtap="postal" id="{{'nav-' + ('postal')}}">{{keyFocus === ('postal') ? '▶ ' : ''}}{{lang === 'zh' ? '邮编' : '郵便番号'}}</button></view>
  <text class="minor" ink:if="{{!cityCode}}">{{lang === 'zh' ? 'GPS 将坐标发送至国土地理院换算地址；由你确认所在地。' : 'GPSは国土地理院へ座標を送信。候補を確認して場所を設定。'}}</text>
  <text class="weather">{{forecast}}</text>
  <text class="status">{{summary}}</text>
  <view class="row"><button bindtap="alerts" id="{{'nav-' + ('alerts')}}">{{keyFocus === ('alerts') ? '▶ ' : ''}}{{lang === 'zh' ? '预警详情' : '警報・地震情報'}}</button><button bindtap="refresh" id="{{'nav-' + ('refresh')}}">{{keyFocus === ('refresh') ? '▶ ' : ''}}{{lang === 'zh' ? '更新' : '更新'}}</button><text class="minor">{{updated}}</text></view>
  <text class="minor">{{message}}</text>
  <view class="row"><button bindtap="earthquake" id="{{'nav-' + ('earthquake')}}">{{keyFocus === ('earthquake') ? '▶ ' : ''}}地震</button><button bindtap="tsunami" id="{{'nav-' + ('tsunami')}}">{{keyFocus === ('tsunami') ? '▶ ' : ''}}{{lang === 'zh' ? '海啸' : '津波'}}</button><button bindtap="landslide" id="{{'nav-' + ('landslide')}}">{{keyFocus === ('landslide') ? '▶ ' : ''}}{{lang === 'zh' ? '土砂' : '土砂'}}</button><button bindtap="flood" id="{{'nav-' + ('flood')}}">{{keyFocus === ('flood') ? '▶ ' : ''}}{{lang === 'zh' ? '暴雨洪水' : '大雨洪水'}}</button></view>
  <view class="row"><button bindtap="typhoon" id="{{'nav-' + ('typhoon')}}">{{keyFocus === ('typhoon') ? '▶ ' : ''}}{{lang === 'zh' ? '台风' : '台風'}}</button><button bindtap="volcano" id="{{'nav-' + ('volcano')}}">{{keyFocus === ('volcano') ? '▶ ' : ''}}火山</button><button bindtap="prepare" id="{{'nav-' + ('prepare')}}">{{keyFocus === ('prepare') ? '▶ ' : ''}}{{lang === 'zh' ? '日常准备' : '日ごろの備え'}}</button><text class="minor">{{lang === 'zh' ? '指南离线可用' : 'ガイドはオフライン対応'}}</text></view>
 </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;box-sizing:border-box;padding:12px 16px;background:#000;color:var(--color-text-primary,#40ff5e);border:1px solid var(--color-primary,#40ff5e);border-radius:10px;}.row{display:flex;flex-direction:row;align-items:center;gap:8px;margin:4px 0;}.top{justify-content:space-between;}.brand{font-size:21px;font-weight:700;}.place{display:block;font-size:19px;font-weight:700;margin:5px 0;}.weather{display:block;font-size:17px;margin-top:8px;}.status{display:block;font-size:14px;margin:6px 0;}.minor{display:block;font-size:11px;color:var(--color-text-secondary,rgba(64,255,94,.65));}button{font-size:13px;padding:5px 10px;border:1px solid var(--color-primary,#40ff5e);border-radius:6px;background:#000;color:var(--color-primary,#40ff5e);}
</style>
