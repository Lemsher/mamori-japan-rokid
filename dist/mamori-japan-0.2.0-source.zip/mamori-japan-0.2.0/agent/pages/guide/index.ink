<script def>
{"navigationBarTitleText":"まもり / 防災ガイド","description":"災害別の重要な行動を一画面で表示するオフラインガイド。","schema":{"data":{"type":"object","properties":{"hazard":{"type":"string","enum":["earthquake","tsunami","landslide","flood","typhoon","volcano","prepare"]},"lang":{"type":"string","enum":["ja","zh"]},"blocked":{"type":"boolean"}},"required":["hazard"]}}}
</script>
<script setup>
import wx from 'wx';
import {handleKeys,methodActions} from '../../modules/keys.js';
import {getBrief} from '../../modules/briefs.js';
import {JAPANESE_TTS_VERIFIED} from '../../modules/config.js';
import {watchRegion} from '../../modules/monitoring.js';
import {eventKey} from '../../modules/alerts.js';
export default {
 onKeyUp(e){handleKeys(this,e,methodActions(this,['back','read','shelters',...(!this.data.isBlocked&&['flood','landslide'].includes(this.data.guide.hazard)?['blocked']:[])]),()=>wx.navigateBack());},
 data:{keyFocus:'',guide:getBrief('prepare'),lang:'ja',message:'',isBlocked:false},
 onLoad(q={}){const lang=q.lang==='zh'?'zh':'ja',blocked=q.blocked===true||q.blocked==='true';this.setData({guide:getBrief(q.hazard,lang,blocked),lang,isBlocked:blocked});},
 onShow(){this._active=true;this._watch=watchRegion(()=>{},a=>wx.navigateTo({url:'/pages/alert/index?lang='+this.data.lang+'&key='+encodeURIComponent(eventKey(a))}));},
 blocked(){this.setData({guide:getBrief(this.data.guide.hazard,this.data.lang,true),isBlocked:true});},
 shelters(){wx.navigateTo({url:'/pages/shelters/index?lang='+this.data.lang+'&hazard='+this.data.guide.hazard});},
 back(){wx.navigateBack();},
 async read(){
  if(this.data.lang==='ja'&&!JAPANESE_TTS_VERIFIED){this.setData({message:'日本語の読上げは実機検証待ち。'});return;}
  if(typeof speechSynthesis==='undefined'||typeof speechSynthesis.synthesize!=='function'||typeof SpeechAudioPlayer!=='function'){this.setData({message:'音声を利用できません / 朗读不可用'});return;}
  const generation=this._speechGeneration=(this._speechGeneration||0)+1;this._player?.destroy();this._speechTask?.abort();
  try{const g=this.data.guide,task=await speechSynthesis.synthesize(new SpeechSynthesisUtterance(g.action+'。'+g.points.map(p=>p.text).join('。')),{subtitles:'none'});if(!this._active||generation!==this._speechGeneration){task.abort();return;}this._speechTask=task;task.finished.catch(()=>{if(this._active)this.setData({message:'音声を利用できません / 朗读不可用'});});this._player=new SpeechAudioPlayer(task);this._player.play();}catch{if(this._active)this.setData({message:'音声を利用できません / 朗读不可用'});}
 },
 onHide(){this._active=false;this._speechGeneration=(this._speechGeneration||0)+1;this._watch?.stop();this._player?.destroy();this._player=null;this._speechTask?.abort();this._speechTask=null;},onUnload(){this.onHide();}
};
</script>
<page>
 <view class="panel">
  <view class="row top"><text class="label">{{guide.title}}</text><text class="label">{{lang === 'zh' ? '离线指南' : 'オフライン'}}</text></view>
  <text class="action">{{guide.action}}</text>
  <view class="points"><view class="point" ink:for="{{guide.points}}" ink:key="id"><text class="dot">•</text><text class="body">{{item.text}}</text></view></view>
  <view class="row"><button bindtap="back" id="{{'nav-' + ('back')}}">{{keyFocus === ('back') ? '▶ ' : ''}}←</button><button bindtap="read" id="{{'nav-' + ('read')}}">{{keyFocus === ('read') ? '▶ ' : ''}}{{lang === 'zh' ? '朗读' : '読上げ'}}</button><button bindtap="shelters" id="{{'nav-' + ('shelters')}}">{{keyFocus === ('shelters') ? '▶ ' : ''}}{{lang === 'zh' ? '附近避难地' : '近くの避難先'}}</button><button ink:if="{{(guide.hazard === 'flood' || guide.hazard === 'landslide') && !isBlocked}}" bindtap="blocked" id="{{'nav-' + ('blocked')}}">{{keyFocus === ('blocked') ? '▶ ' : ''}}{{lang === 'zh' ? '无法外出' : '外出困難'}}</button></view>
  <text class="note">{{message || (lang === 'zh' ? '119 救援 · 阅读完毕不代表危险解除。依据气象厅/内阁府指南。' : '119 救助・読み終えても警報解除ではありません。気象庁/内閣府資料の要約。')}}</text>
 </view>
</page>
<style>
.panel{width:480px;height:352px;padding:14px 16px;box-sizing:border-box;background:#000;color:var(--color-text-primary,#40ff5e);border:1px solid var(--color-primary,#40ff5e);border-radius:10px;display:flex;flex-direction:column;}.row{display:flex;flex-direction:row;align-items:center;gap:8px;}.top{justify-content:space-between;}.label{font-size:12px;}.action{display:block;font-size:23px;font-weight:700;margin:12px 0;}.points{flex:1;}.point{display:flex;flex-direction:row;gap:8px;margin-bottom:10px;}.dot{font-size:17px;}.body{font-size:16px;line-height:1.35;flex:1;}.note{display:block;font-size:10px;margin-top:8px;color:var(--color-text-secondary,rgba(64,255,94,.65));}button{font-size:12px;padding:6px 8px;border:1px solid var(--color-primary,#40ff5e);border-radius:6px;background:#000;color:var(--color-primary,#40ff5e);}
</style>
