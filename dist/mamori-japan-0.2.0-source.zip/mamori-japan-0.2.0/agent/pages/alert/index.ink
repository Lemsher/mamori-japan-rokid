<script def>
{"navigationBarTitleText":"まもり / 警報・地震情報"}
</script>
<script setup>
import wx from 'wx';
import {handleKeys,methodActions} from '../../modules/keys.js';
import {snapshotAlerts,alertView,countdown,eventKey} from '../../modules/alerts.js';
import {cachedSnapshot,watchRegion} from '../../modules/monitoring.js';
export default {
 onKeyUp(e){handleKeys(this,e,methodActions(this,['back',...(this.data.alert?['guide','shelters']:[]),...(this.data.count>1?['next']:[]),'coast']),()=>wx.navigateBack());},
 data:{keyFocus:'',lang:'ja',alert:null,count:0,index:0,message:'',coast:''},
 onLoad(q={}){this._key=q.key||'';this.setData({lang:q.lang==='zh'?'zh':'ja'});this.paint(cachedSnapshot());},
 onShow(){this._watch=watchRegion(s=>this.paint(s),a=>{this._key=eventKey(a);this.paint(cachedSnapshot());});this._timer=setInterval(()=>{if(this.data.alert)this.setData({alert:{...this.data.alert,timing:countdown(this.data.alert,this._snapshot,this.data.lang)}});},1000);},
 paint(s){this._snapshot=s;this._items=snapshotAlerts(s);let index=Math.max(0,this._items.findIndex(a=>eventKey(a)===this._key));const a=this._items[index];this.setData({alert:a?alertView(a,s,this.data.lang):null,count:this._items.length,index,coast:s?.events?.coast||'',message:a?'':this.data.lang==='zh'?'本次未取得匹配记录；不表示安全或解除。':'該当記録を取得できていません。安全・解除を意味しません。'});},
 next(){if(!this._items?.length)return;this._key=eventKey(this._items[(this.data.index+1)%this._items.length]);this.paint(this._snapshot);},
 guide(){if(this.data.alert)wx.navigateTo({url:'/pages/guide/index?hazard='+this.data.alert.hazard+'&lang='+this.data.lang});},
 shelters(){if(this.data.alert)wx.navigateTo({url:'/pages/shelters/index?hazard='+this.data.alert.hazard+'&lang='+this.data.lang});},
 coast(){wx.navigateTo({url:'/pages/location/index?action=coast&lang='+this.data.lang});},
 back(){wx.navigateBack();},
 onHide(){this._watch?.stop();clearInterval(this._timer);},onUnload(){this.onHide();}
};
</script>
<page>
 <scroll-view class="panel" scroll-y="true" scroll-into-view="{{'nav-' + keyFocus}}">
  <view class="row top"><button bindtap="back" id="{{'nav-' + ('back')}}">{{keyFocus === ('back') ? '▶ ' : ''}}←</button><text class="minor">{{lang === 'zh' ? '地区灾害信息' : '地域の災害情報'}}</text><text class="minor">{{count ? index+1 : 0}} / {{count}}</text></view>
  <view ink:if="{{alert}}">
   <text class="state">{{alert.stateLabel}}</text><text class="heading">{{alert.name}}</text><text class="area">{{alert.city}}</text>
   <view class="metric" ink:for="{{alert.metrics}}" ink:key="label"><text class="minor">{{item.label}}</text><text class="value">{{item.value}}</text></view>
   <text class="timing">{{alert.timing}}</text><text class="minor">{{alert.time}} · {{alert.publisher}}</text>
   <view class="row"><button bindtap="guide" id="{{'nav-' + ('guide')}}">{{keyFocus === ('guide') ? '▶ ' : ''}}{{lang === 'zh' ? '立即查看应对' : '今すぐ行動確認'}}</button><button bindtap="shelters" id="{{'nav-' + ('shelters')}}">{{keyFocus === ('shelters') ? '▶ ' : ''}}{{lang === 'zh' ? '避难地' : '避難先'}}</button><button bindtap="next" ink:if="{{count > 1}}" id="nav-next">{{keyFocus === 'next' ? '▶ ' : ''}}{{lang === 'zh' ? '其他预警' : '他の情報'}}</button></view>
  </view>
  <text class="area">{{message}}</text>
  <button bindtap="coast" id="{{'nav-' + ('coast')}}">{{keyFocus === ('coast') ? '▶ ' : ''}}{{coast || (lang === 'zh' ? '确认海啸预报沿岸' : '津波予報の沿岸を確認')}}</button>
  <text class="minor">{{lang === 'zh' ? '公开信息约每分钟更新；秒级地震预警尚未接通。' : '公開情報は約1分周期。秒単位の緊急地震速報は未接続。'}}</text>
 </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;padding:12px 16px;box-sizing:border-box;background:#000;color:var(--color-text-primary,#40ff5e);border:3px solid var(--color-primary,#40ff5e);}.row{display:flex;flex-direction:row;align-items:center;gap:8px;margin:8px 0;}.top{justify-content:space-between;}.minor,.state{display:block;font-size:11px;margin:5px 0;}.state{font-weight:700;}.heading{display:block;font-size:22px;font-weight:700;margin:8px 0;}.area{display:block;font-size:15px;margin:8px 0;}.metric{display:flex;flex-direction:row;justify-content:space-between;gap:10px;margin:6px 0;}.value{font-size:16px;font-weight:700;}.timing{display:block;font-size:17px;font-weight:700;margin:10px 0;}button{font-size:12px;padding:6px 8px;border:1px solid var(--color-primary,#40ff5e);border-radius:6px;background:#000;color:var(--color-primary,#40ff5e);}
</style>
