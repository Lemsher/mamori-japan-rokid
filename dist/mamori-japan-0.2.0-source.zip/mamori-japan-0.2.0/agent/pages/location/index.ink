<script def>
{"navigationBarTitleText":"まもり / 場所を選択"}
</script>
<script setup>
import wx from 'wx';
import {handleKeys,methodActions} from '../../modules/keys.js';
import {OFFICES,searchCities,rememberCity,locateCities,locationError,COASTS,rememberCoast} from '../../modules/locations.js';
import {startTextInput} from '../../modules/text-input.js';
export default {
 onKeyUp(e){handleKeys(this,e,methodActions(this,['back','search','listen','showOffices','locate','postal','showCoasts']).concat(this.data.items.map(item=>({id:'item-'+item.code,run:()=>this.selectItem({currentTarget:{attributes:{'data-code':item.code}}})})),methodActions(this,[...(this.data.offset>0?['previous']:[]),...(this.data.offset+4<this.data.total?['next']:[])])),()=>wx.navigateBack());},
  data:{keyFocus:'',lang:'ja',query:'',items:[],title:'地域一覧 / 地区列表',message:'',pageLabel:'',offset:0,total:0,locating:false},
  onLoad(q={}){this._active=true;this.setData({lang:q.lang==='zh'?'zh':'ja',query:q.query||''});if(q.action==='coast')this.showCoasts();else if(q.query)this.search();else this.showOffices();if(q.action==='locate')this.locate();if(q.action==='postal')this.postal();},
  t(ja,zh){return this.data.lang==='zh'?zh:ja;},
  input(e){this.setData({query:String(e.detail?.value ?? e.currentTarget?.value ?? '')});},
  present(items,title){this._items=items;this.setData({keyFocus:'',title,offset:0,total:items.length});this.renderList();},
  renderList(){const offset=this.data.offset;this.setData({items:this._items.slice(offset,offset+4),pageLabel:this._items.length?(Math.floor(offset/4)+1)+' / '+Math.ceil(this._items.length/4):'0 / 0'});},
  cancelLocate(){this._generation=(this._generation||0)+1;this.setData({locating:false});},
  showOffices(){this.cancelLocate();this.present(OFFICES.map(o=>({...o,label:o.name,kind:'office'})),this.t('地域一覧','地区列表'));this.setData({message:this.t('文字入力ができない場合も、一覧から選べます。','无法键盘输入时，也可用镜腿操作逐级选择。')});},
  search(){
    this.cancelLocate();
    const q=this.data.query.trim();
    if(!q){this.showOffices();return;}
    const results=searchCities(q).map(c=>({...c,label:c.office+' '+c.name,kind:'city'}));
    this.present(results,this.t('検索候補：選択して確定','搜索候选：选择即确认'));
    this.setData({message:results.length?this.t('市町村名を確認して選択してください。','请核对市町村名称后选择。'):this.t('市町村名・かな・英語で入力、または一覧を選択。','请输入含市町村的地址、日文假名或英文；也可选择地区列表。')});
  },
  postal(){this.setData({query:'',message:this.t('7桁の郵便番号を音声またはStudio右側に入力。','请输入7位日本邮编，例如150-0001；可语音或在Studio右侧输入。')});this.listen();},
  showCoasts(){this.cancelLocate();this.present(COASTS.map(([name,description],i)=>({code:String(i),name,label:name,description,kind:'coast'})),this.t('対象の沿岸を確認して選択','请确认所在的海啸预报沿岸'));this.setData({message:this.t('市町村と海岸区分は異なります。海岸を確認して選択。','市町村与海啸预报区不同，请确认对应沿岸后选择。')});},
  selectItem(e){
    this.cancelLocate();const item=this._items.find(i=>i.code===e.currentTarget.attributes['data-code']);if(!item)return;
    if(item.kind==='coast'){rememberCoast(item.name,typeof localStorage==='undefined'?null:localStorage);wx.redirectTo({url:'/pages/home/index?lang='+this.data.lang});return;}
    if(item.kind==='office'){this.present(searchCities('',item.code).map(c=>({...c,label:c.name,kind:'city'})),item.name);this.setData({message:this.t('市町村を選択して確定','选择市町村即确认查询地点')});return;}
    const storage=typeof localStorage==='undefined'?null:localStorage;rememberCity(item.code,storage);
    wx.redirectTo({url:'/pages/home/index?cityCode='+item.code+'&lang='+this.data.lang});
  },
  next(){this.setData({offset:Math.min(Math.max(0,Math.floor((this.data.total-1)/4)*4),this.data.offset+4)});this.renderList();},
  previous(){this.setData({offset:Math.max(0,this.data.offset-4)});this.renderList();},
  back(){this.cancelLocate();wx.navigateBack();},
  onVoiceWakeup(){this.listen();},
  listen(){
    if(this._recognition){this._recognition.abort();this._recognition=null;}
    this.setData({message:this.t('住所を話すか、Studioの右側に入力して送信。','请说出地址，或在 Studio 右侧输入地址并发送。')});
    this._recognition=startTextInput(text=>{if(!this._active)return;this.setData({query:text});this.search();},()=>{if(this._active)this.setData({message:this.t('音声/文字入力を開始できません。一覧を使用。','宿主未能启动输入，请使用地区列表。')});},()=>{this._recognition=null;});
  },
  async locate(){
    if(this.data.locating)return;const generation=this._generation=(this._generation||0)+1;
    this.setData({locating:true,message:this.t('位置情報を取得中。権限の確認が表示されたら選択してください。','正在定位；如出现系统权限提示，请自行选择是否允许。')});
    try{
      const result=await locateCities(typeof navigator==='undefined'?null:navigator.geolocation);
      if(!this._active||generation!==this._generation)return;
      this.present(result.cities.map(c=>({...c,label:c.office+' '+c.name,kind:'city'})),this.t('位置情報の候補：確認して選択','定位候选：请核对并选择'));
      this.setData({message:this.t('推定誤差 '+result.accuracy+' m。自動確定しません。','定位误差约 '+result.accuracy+' 米，请自行确认市町村。')});
    }catch(e){if(this._active&&generation===this._generation)this.setData({message:locationError(e,this.data.lang)});}
    finally{if(this._active&&generation===this._generation)this.setData({locating:false});}
  },
  onHide(){this._active=false;this.cancelLocate();if(this._recognition)this._recognition.abort();this._recognition=null;},
  onShow(){this._active=true;},onUnload(){this.onHide();}
};
</script>
<page>
  <scroll-view class="panel" scroll-y="true" scroll-into-view="{{'nav-' + keyFocus}}">
    <view class="row top"><button bindtap="back" id="{{'nav-' + ('back')}}">{{keyFocus === ('back') ? '▶ ' : ''}}←</button><text class="heading">場所 / 地点</text><text class="caption">{{pageLabel}}</text></view>
    <text class="message">{{message}}</text>
    <input class="address" value="{{query}}" maxLength="150" placeholder="東京都渋谷区 / 150-0001" bindinput="input" />
    <text class="caption">{{lang === 'zh' ? '定位会向国土地理院发送坐标，不保存坐标；也可手动选择。' : '測位時は国土地理院に座標を送信。座標は保存せず、手動選択も可能。'}}</text>
    <view class="row"><button bindtap="search" id="{{'nav-' + ('search')}}">{{keyFocus === ('search') ? '▶ ' : ''}}検索 / 搜索</button><button bindtap="listen" id="{{'nav-' + ('listen')}}">{{keyFocus === ('listen') ? '▶ ' : ''}}入力 / 输入</button><button bindtap="showOffices" id="{{'nav-' + ('showOffices')}}">{{keyFocus === ('showOffices') ? '▶ ' : ''}}一覧 / 列表</button><button bindtap="locate" disabled="{{locating}}" id="{{'nav-' + ('locate')}}">{{keyFocus === ('locate') ? '▶ ' : ''}}定位</button></view>
    <view class="row"><button bindtap="postal" id="{{'nav-' + ('postal')}}">{{keyFocus === ('postal') ? '▶ ' : ''}}郵便番号 / 邮编</button><button bindtap="showCoasts" id="{{'nav-' + ('showCoasts')}}">{{keyFocus === ('showCoasts') ? '▶ ' : ''}}津波沿岸 / 海啸区域</button></view>
    <text class="caption">{{title}} · {{total}}</text>
    <button class="choice" ink:for="{{items}}" ink:key="code" data-code="{{item.code}}" bindtap="selectItem" id="{{'nav-' + ('item-' + item.code)}}">{{keyFocus === ('item-' + item.code) ? '▶ ' : ''}}{{item.label}}</button>
    <view class="row"><button bindtap="previous" disabled="{{offset === 0}}" id="{{'nav-' + ('previous')}}">{{keyFocus === ('previous') ? '▶ ' : ''}}← 前页</button><button bindtap="next" disabled="{{offset + 4 >= total}}" id="nav-next">{{keyFocus === 'next' ? '▶ ' : ''}}后页 →</button></view>
  </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;padding:12px;box-sizing:border-box;background:#000;color:var(--color-text-primary,#40ff5e);border:2px solid var(--color-primary,#40ff5e);border-radius:12px;}
.row{display:flex;flex-direction:row;align-items:center;gap:8px;margin:4px 0;}.top{justify-content:space-between;}.heading{font-size:18px;font-weight:700;}.message{display:block;font-size:13px;line-height:1.3;margin:4px 0;}.caption{display:block;font-size:11px;margin:4px 0;color:var(--color-text-secondary,rgba(64,255,94,.6));}
.address{height:32px;--input-border-width:0px;--input-padding-x:0px;--input-padding-y:0px;--input-background-color:transparent;}
button{font-size:13px;border:1px solid var(--color-primary,#40ff5e);background:#000;color:var(--color-primary,#40ff5e);padding:5px 8px;border-radius:8px;}.choice{margin:3px 0;text-align:left;}
</style>
