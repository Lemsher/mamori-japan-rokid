import { SERVICE_URL } from './config.js';

export function jstTime(value) {
  const date = new Date(Date.parse(value)+9*3600000);
  if(!Number.isFinite(date.getTime()))return '未確認';
  return date.toISOString().slice(5,16).replace('T',' ')+' JST';
}

export async function getJSON(path) {
  if (!SERVICE_URL || !/^https:\/\//.test(SERVICE_URL)) throw new Error('service-unconfigured');
  const response = await fetch(SERVICE_URL.replace(/\/$/,'') + path, {timeout:18000});
  if (!response.ok) throw new Error('source-unavailable');
  return response.json();
}

export function isSnapshotFresh(snapshot, now = Date.now()) {
  const issued = Date.parse(snapshot?.checkedAt);
  return Number.isFinite(issued) && now-issued >= -60000 && now-issued < 120000 && snapshot?.dataState !== 'unavailable';
}

export function warningSummary(snapshot, lang = 'ja', now = Date.now()) {
  const zh = lang === 'zh';
  if (!isSnapshotFresh(snapshot,now)) return zh ? '最新预警未确认，请查看官方信息。' : '最新の警報は未確認。公式情報を確認。';
  const w = snapshot.warnings;
  if (!w || w.state === 'partial') return zh ? '部分预警数据未确认，请查看官方信息。' : '警報の一部が未確認。公式情報を確認。';
  return w.alerts.length ? w.alerts.map(a=>a.name).join(' / ') : (zh ? '本次取得范围内未列出预警；不代表安全。' : '取得範囲に警報等の掲載なし。安全を意味しません。');
}
