<script def>
{
  "navigationBarTitleText": "まもり"
}
</script>
<script setup>
import wx from 'wx';
import { getJSON, warningSummary, isSnapshotFresh, jstTime } from '../../modules/client.js';
import { resolveIntent, classifyIntent } from '../../modules/playbooks.js';
import { SERVICE_URL } from '../../modules/config.js';
import {cityByCode,rememberCity,recalledCity,searchCities} from '../../modules/locations.js';
import {startTextInput} from '../../modules/text-input.js';
export default {
  data: {lang:'ja',cityCode:'',city:'場所を選択',summary:'最新の警報は未確認。',forecast:'',query:'',busy:false,
    bulletins:[],message:''},
  onLoad(q = {}) {
    const storage=typeof localStorage==='undefined'?null:localStorage;
    const city=cityByCode(q.cityCode)||recalledCity(storage);
    this.setData({lang:q.lang === 'zh' ? 'zh' : 'ja',cityCode:city?.code||'',city:city?city.office+' '+city.name:'場所を選択 / 选择地点'});
    if(city){rememberCity(city.code,storage);this.refresh();}
    else this.setData({message:'場所・住所はオフラインで選べます / 地点选择无需连接天气服务'});
  },
  onShow() {
    this._hidden=false;
    if (this._snapshot) {
      this.setData({summary:warningSummary(this._snapshot,this.data.lang)});
      if(!isSnapshotFresh(this._snapshot))this.setData({bulletins:[],forecast:'天気予報は再取得してください / 请刷新预报'});
      else this._expiry=setTimeout(()=>this.setData({bulletins:[],summary:warningSummary(this._snapshot,this.data.lang),forecast:'天気予報は再取得してください / 请刷新预报'}),Math.max(0,120000-(Date.now()-Date.parse(this._snapshot.checkedAt))));
    }
  },
  chooseCity() {wx.navigateTo({url:'/pages/location/index?lang='+this.data.lang+'&query='+encodeURIComponent(this.data.query)});},
  language(){this.setData({lang:this.data.lang==='ja'?'zh':'ja'});},
  async refresh() {
    if (this.data.busy) return;
    if(!this.data.cityCode){this.setData({message:'先に場所を選択 / 请先选择地点'});return;}
    if(!SERVICE_URL){this.setData({summary:'最新警報は未確認 / 最新预警未确认',message:this.data.lang==='zh'?'地点已保存。天气服务尚未配置；离线指南可用。':'場所を保存しました。天気サービス未設定。防災ガイドは利用できます。'});return;}
    const request=this._request=(this._request||0)+1;
    clearTimeout(this._expiry);
    this.setData({busy:true,forecast:'',bulletins:[],summary:'取得中 / 查询中'});
    try {
      const res = await getJSON('/api/snapshot?city='+encodeURIComponent(this.data.cityCode));
      if (this._hidden || request!==this._request) return;
      this._snapshot = res;
      const day = isSnapshotFresh(res) && res.forecast && !res.forecast.stale && res.forecast.days[0];
      const reports=(res.warnings&&res.warnings.reports)||[];
      const latest=reports.slice().sort((a,b)=>Date.parse(b.issuedAt)-Date.parse(a.issuedAt))[0];
      this.setData({city:res.city.office+' '+res.city.name,summary:warningSummary(res,this.data.lang),
        forecast:day ? res.forecast.area+'：'+day.condition+' / 予報発表 '+jstTime(res.forecast.issuedAt) : '天気予報 未確認 / 天气未确认',
        bulletins:isSnapshotFresh(res)?res.national.slice(0,3).map(e=>({...e,time:jstTime(e.issuedAt)})):[],
        message:'取得 '+jstTime(res.checkedAt)+(latest?' / 警報電文 '+jstTime(latest.issuedAt):'')+' / 自治体避難情報は未接続'});
      clearTimeout(this._expiry);
      this._expiry=setTimeout(()=>this.setData({bulletins:[],summary:warningSummary(res,this.data.lang),forecast:'天気予報は再取得してください / 请刷新预报'}),120000);
    } catch {if(request===this._request&&!this._hidden){this._snapshot=null;this.setData({summary:'最新の警報は未確認 / 最新预警未确认',message:'接続先・通信を確認 / 请检查服务配置与网络'});}}
    finally {if(!this._hidden&&request===this._request)this.setData({busy:false});}
  },
  async ask() {
    const quick=classifyIntent(this.data.query);
    if(quick.intent!=='weather'&&quick.intent!=='unknown'){this.openGuide(quick.intent,quick.blocked);return;}
    if(searchCities(this.data.query).length&&this.data.query.trim()){this.chooseCity();return;}
    if (this._asking) return;
    this._asking=true;
    const r=await resolveIntent(this.data.query,typeof LanguageModel === 'undefined' ? null : LanguageModel);
    this._asking=false;
    if(this._hidden)return;
    if(r.intent==='weather'){this.refresh();return;}
    if(r.intent==='unknown'){this.setData({message:'災害名を選択 / 请选择灾害类型'});return;}
    this.openGuide(r.intent,r.blocked);
  },
  openGuide(hazard,blocked=false) {wx.navigateTo({url:'/pages/guide/index?hazard='+hazard+'&lang='+this.data.lang+'&blocked='+blocked});},
  earthquake(){this.openGuide('earthquake');}, tsunami(){this.openGuide('tsunami');},
  landslide(){this.openGuide('landslide');}, flood(){this.openGuide('flood');}, prepare(){this.openGuide('prepare');},
  typhoon(){this.openGuide('typhoon');}, volcano(){this.openGuide('volcano');},
  onVoiceWakeup(){this.listen();},
  listen() {
    if(this._recognition){this._recognition.abort();this._recognition=null;}
    this.setData({message:'住所・状況を入力 / Studio 右侧输入地址或情况后发送'});
    this._recognition=startTextInput(text=>{if(this._hidden)return;this.setData({query:text,message:''});this.ask();},()=>this.setData({message:'宿主输入不可用，请通过镜腿操作选择“地点”'}),()=>{this._recognition=null;});
  },
  onHide(){this._hidden=true;this._request=(this._request||0)+1;clearTimeout(this._expiry);if(this._recognition)this._recognition.abort();this._recognition=null;this.setData({busy:false});},
  onUnload(){this.onHide();}
};
</script>
<page>
  <scroll-view class="panel" scroll-y="true">
    <view class="top"><text class="title">まもり</text><text class="small">v0.1.1</text><button bindtap="language">日本語 / 中文</button></view>
    <text class="location">{{city}}</text>
    <text class="status">{{summary}}</text>
    <text class="small">{{forecast}}</text>
    <view class="controls">
      <view class="row"><button bindtap="chooseCity">場所 / 地点</button><button bindtap="listen">入力 / 输入</button><button bindtap="refresh">更新 / 刷新</button></view>
      <text class="small" ink:if="{{query}}">{{query}}</text>
      <view class="row"><button bindtap="earthquake">地震</button><button bindtap="tsunami">津波</button><button bindtap="landslide">土砂</button><button bindtap="flood">洪水</button><button bindtap="prepare">備え</button></view>
      <view class="row"><button bindtap="typhoon">台風</button><button bindtap="volcano">火山</button></view>
    </view>
    <text class="small">{{message}}</text>
    <view ink:if="{{bulletins.length > 0}}">
      <text class="small">全国発表履歴 / 全国通报历史。現地の警報状態ではありません。</text>
      <view ink:for="{{bulletins}}" ink:key="id"><text class="small">{{item.title}} / {{item.time}}</text><text class="small">{{item.summary}}</text></view>
    </view>
    <text class="small">119 救急・救助 / 110 警察</text>
    <text class="small">Studio：镜腿单击激活、滑动切换、再单击确认。麦克风可模拟文字输入。</text>
  </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;box-sizing:border-box;padding:18px;background:var(--color-background,#000);color:var(--color-text-primary,#40ff5e);border:2px solid var(--color-primary,#40ff5e);border-radius:12px;}
.top,.row{display:flex;flex-direction:row;align-items:center;gap:8px;}.top{justify-content:space-between;}.title{font-size:24px;font-weight:700;font-family:monospace;}.location{display:block;font-size:18px;font-weight:700;margin-top:12px;}.status{display:block;font-size:18px;margin:12px 0;}.small{display:block;font-size:11px;margin-top:6px;color:var(--color-text-secondary,rgba(64,255,94,.6));}
.row{margin:8px 0;}button{font-size:13px;color:var(--color-primary,#40ff5e);border:2px solid var(--color-primary,#40ff5e);background:#000;border-radius:12px;padding:8px;}
</style>
