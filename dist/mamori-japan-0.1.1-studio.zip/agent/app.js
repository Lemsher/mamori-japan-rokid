export default {
  globalData: { version: '0.1.1', language: 'ja' },
  onLaunch() {},
};
