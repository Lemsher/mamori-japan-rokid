# 官方资料与实现对应

核对日期：2026-09-11。Rokid 文档采用公开 `0.17.0 / v0.17.0` 版本；不依赖搜索摘要来猜测 API。`reference/` 是本地研究快照，交付源码压缩包不包含这些完整文档。

| 官方来源 | 在本项目中的用途 |
| --- | --- |
| [Rokid AIUI](https://js.rokid.com/) | Open Agent Format、`AGENTS.md`、`app.json`、`.ink` 四区块、页面数据绑定及生命周期 |
| [AI 开发指南](https://js.rokid.com/AIUI/guide/quickstart/ai-dev?version=0.17.0) | 官方 `aiui-dev` Skill 的原生布局、语法、能力使用说明 |
| [只读卡片与全屏目标](https://js.rokid.com/AIUI/framework/open-agent-format/target?version=0.17.0) | target 与交互能力有区别；Studio 可在 `_current` 下通过 `setInteractive` 开启交互，因此不再按 target 隐藏控件 |
| [单色视觉规范](https://js.rokid.com/AIUI/design/visual/monochrome?version=0.17.0) | 480×352、黑底单绿色、token、描边与文字层级 |
| [HTTP 网络使用](https://js.rokid.com/AIUI/guide/basic/network/usage?version=0.17.0) | HTTPS 服务与域名配置边界 |
| [LanguageModel](https://js.rokid.com/AIUI/api/ai/language-model?version=0.17.0) | availability/create/prompt/destroy；本项目进一步限制为枚举分类 |
| [语音识别](https://js.rokid.com/AIUI/api/ai/speech-recognition?version=0.17.0)、[语音播报](https://js.rokid.com/AIUI/api/ai/speech-synthesis?version=0.17.0) | 原生能力检测、用户触发；日语支持保留实机验证门槛 |
| [Navigator / 定位入口](https://js.rokid.com/AIUI/api/navigator?version=0.17.0) | `navigator.geolocation`，权限和实际能力由宿主提供 |
| [Studio 官方操作指南](https://openrokid.csdn.net/6a9a124a790f037e6e388dab.html) | 本地目录导入、真机模拟和效果预览；另现场核对公开 Studio JS 中的画布、镜腿及 ASR 模拟实现 |
| [GSI 市町村代码](https://maps.gsi.go.jp/js/muni.js)、[官方项目中的地址转换说明](https://github.com/gsi-cyberjapan/gsimaps/issues/29) | 定位转 JIS 代码，再映射 JMA 候选；服务不保证持续提供，须保留手动入口。政令市分区不能机械拼接代码 |
| [通知下发](https://js.rokid.com/AIUI/cloud/notifications?version=0.17.0) | 服务端 Bearer SK、message/account/agent、页面参数、业务成功条件 |
| [AIX CLI](https://js.rokid.com/AIUI/guide/bundle/cli?version=0.17.0) | 官方打包、查看包内容、生成 Ink HTML 预览 |
| [JMA XML PULL](https://xml.kishou.go.jp/xmlpull.html) | extra/regular/eqvol 高频及长周期订阅、缓存策略、时延和完整性边界 |
| [2026 新防灾气象信息](https://www.jma.go.jp/jma/kishou/know/bosai/keiho-update2026/)、[技术资料](https://www.jma.go.jp/jma/kishou/know/bosai/keiho-update2026/tech-info/index.html) | 2026-05-29 开始的新制名称和等级；VPWW55–61 与旧 VPWW53 兼容 |
| [JMA 地区代码表](https://www.jma.go.jp/bosai/common/const/area.json) | class20 → class15 → class10 → office 精确代码链，保存为 `data/areas.json` |
| [紧急地震速报行动指南](https://www.jma.go.jp/jma/kishou/know/jishin/eew/koudou/koudou.html) | 摇晃中先护身，不等待网络；并非提供 EEW 接入 |
| [海啸防灾](https://www.jma.go.jp/jma/kishou/know/jishin/tsunami_bosai/index.html) | 沿岸强烈/长时间摇晃后的避难、海啸反复到达、解除前不返回 |
| [土砂灾害信息](https://www.jma.go.jp/jma/kishou/know/bosai/doshakeikai.html) | 远离陡坡溪谷、早期避难、室外危险时的相对避险 |
| [喷发速報与行动](https://www.jma.go.jp/jma/kishou/know/kazan/funkasokuho/funkasokuho_toha.html) | 火山管制、保护头部、避难壕/坚固建筑与现场指示 |
| [内阁府避难信息指南](https://www.bousai.go.jp/oukyu/hinanjouhou/r3_hinanjouhou_guideline/index.html) | 等级 3/4/5 的行动意义与不可等待等级 5；具体场景仍需地方政府指示 |
| [灾害地图门户](https://disaportal.gsi.go.jp/) | 按所在地和灾种确认风险，不伪造路线或避难所开放状态 |
| [消防厅 119](https://www.fdma.go.jp/mission/enrichment/kyukyumusen_kinkyutuhou/119.html) | 急救、火警和救援信息入口 |

## 公开电文夹具

- `tests/fixtures/jma-landslide-20260911.xml`：[2026-09-11 VPWW56 山梨县电文](https://www.data.jma.go.jp/developer/xml/data/20260911022049_0_VPWW56_190000.xml)。用同一正文测试大月市等级 2、山梨市解除状态和其他市町村不匹配，不能将其当作之后日期的实时警报。
- `tests/fixtures/jma-forecast-20260911.xml`：2026-09-11 的 VPFD51 东京地区天气预报，用于固定回归测试。实际服务只通过官方当前 feed 发现和读取最新公开电文。

全国地震/火山/海啸栏仅显示 feed 中的标题、摘要及发布时刻。本版未做这些电文的精确空间影响区解析、连续有效性追踪、撤销闭环，因此不将其转换为本地报警。
