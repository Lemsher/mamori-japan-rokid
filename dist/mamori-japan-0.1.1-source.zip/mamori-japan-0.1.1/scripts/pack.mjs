import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
fs.mkdirSync('dist',{recursive:true});
const run=args=>{const r=spawnSync(process.execPath,args,{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);};
run(['scripts/check-agent.mjs']);
const cli='node_modules/@yodaos-pkg/aix-cli/dist/cli.js';
const version=JSON.parse(fs.readFileSync('package.json')).version;
run([cli,'pack','agent','-o',`dist/mamori-japan-${version}.aix`,'--engine','0.17.0']);
run([cli,'list',`dist/mamori-japan-${version}.aix`]);
run([cli,'preview','agent','--html-out','preview/aiui-runtime.html']);
// Pin the browser engine, and use documented OpenBundleOptions for full-screen QA.
const previewPath='preview/aiui-runtime.html';
let html=fs.readFileSync(previewPath,'utf8').replace('https://esm.sh/@yodaos-pkg/ink"','https://esm.sh/@yodaos-pkg/ink@0.17.0"');
const original='view.openBundle({\n          appId: state.appId,\n          files: bundleFiles(state.files),\n        });';
if(!html.includes(original))throw new Error('CLI preview mount changed: review the full-screen patch');
html=html.replace(original,`const launch = new URLSearchParams(location.search);
        view.openBundle({ appId: state.appId, files: bundleFiles(state.files),
          initialPage: launch.get('page') === 'guide' ? 'pages/guide/index' : launch.get('page') === 'location' ? 'pages/location/index' : 'pages/home/index',
          query: {hazard:launch.get('hazard') || 'prepare',lang:launch.get('lang') || 'ja',query:launch.get('query') || '',cityCode:launch.get('cityCode') || ''},
          hostOptions:{initialTarget:launch.get('target') === '_current' ? '_current' : '_blank', initialFocus:'focus'} });`);
fs.writeFileSync(previewPath,html);
