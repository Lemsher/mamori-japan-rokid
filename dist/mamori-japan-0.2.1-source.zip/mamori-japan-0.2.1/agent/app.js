export default {
  globalData: { version: '0.2.1', language: 'ja' },
  onLaunch() {},
};
