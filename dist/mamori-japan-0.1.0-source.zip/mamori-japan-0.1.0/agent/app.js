export default {
  globalData: { version: '0.1.0', language: 'ja' },
  onLaunch() {},
};
