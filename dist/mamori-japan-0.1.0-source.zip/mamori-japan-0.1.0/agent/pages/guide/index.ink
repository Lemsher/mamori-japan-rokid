<script def>
{
  "navigationBarTitleText":"まもり / 行動ガイド",
  "description":"日本の災害時の自救行動を端末内の公式資料要約から表示。ネット不要。即時の危険には最初の行動をすぐ示す。手順の終了は安全や解除を意味しない。",
  "schema":{"data":{"type":"object","properties":{
    "hazard":{"type":"string","enum":["earthquake","tsunami","landslide","flood","typhoon","volcano","prepare"]},
    "lang":{"type":"string","enum":["ja","zh"]},
    "blocked":{"type":"boolean","description":"冠水などで屋外移動が危険か。"}
  },"required":["hazard"]}}
}
</script>
<script setup>
import {getGuide} from '../../modules/playbooks.js';
import {JAPANESE_TTS_VERIFIED} from '../../modules/config.js';
export default {
  data:{guide:getGuide('prepare'),step:0,lang:'ja',message:'',done:false},
  onLoad(q={}){this.setData({guide:getGuide(q.hazard,q.lang,q.blocked===true||q.blocked==='true'),lang:q.lang==='zh'?'zh':'ja',step:0});},
  next(){if(this.data.step < this.data.guide.steps.length-1)this.setData({step:this.data.step+1});else this.setData({done:true});},
  previous(){this.setData({step:Math.max(0,this.data.step-1),done:false});},
  blocked(){this.setData({guide:getGuide(this.data.guide.hazard,this.data.lang,true),step:0,done:false});},
  onKeyDown(e){if(e.code==='ArrowRight')this.next();if(e.code==='ArrowLeft')this.previous();},
  read(){
    if(this.data.lang==='ja'&&!JAPANESE_TTS_VERIFIED){this.setData({message:'日本語音声は未検証。画面の手順を確認。'});return;}
    if(typeof speechSynthesis==='undefined'){this.setData({message:'音声を利用できません / 朗读不可用'});return;}
    try{const step=this.data.guide.steps[this.data.step];const u=new SpeechSynthesisUtterance(step.title+'。'+step.detail);speechSynthesis.speak(u,'immediate');}
    catch{this.setData({message:'音声を利用できません / 朗读不可用'});}
  }
};
</script>
<page>
  <scroll-view class="panel" scroll-y="true">
    <view class="top"><text class="label">{{guide.title}}</text><text class="label">{{step+1}} / {{guide.steps.length}}</text></view>
    <text class="heading">{{guide.steps[step].title}}</text>
    <text class="body">{{guide.steps[step].detail}}</text>
    <view class="controls"><button bindtap="previous">←</button><button bindtap="read">読上げ / 朗读</button><button bindtap="next">次へ / 下一步 →</button></view>
    <view class="controls" ink:if="{{guide.hazard === 'flood' || guide.hazard === 'landslide'}}"><button bindtap="blocked">移動が危険 / 无法安全外出</button></view>
    <text class="note" ink:if="{{done}}">{{guide.footer}}</text>
    <text class="note">{{message}}</text>
    <text class="note">公式資料の要約 / 官方资料摘要 · 119 救急・救助</text>
    <text class="source">{{guide.source}}</text>
  </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;padding:18px;box-sizing:border-box;border:2px solid var(--color-primary,#40ff5e);border-radius:12px;background:var(--color-background,#000);color:var(--color-text-primary,#40ff5e);}.top,.controls{display:flex;flex-direction:row;justify-content:space-between;gap:12px;}.label{font-size:13px;font-weight:700;font-family:sans-serif;}.heading{display:block;font-size:24px;font-weight:700;font-family:monospace;margin:18px 0 12px;}.body{display:block;font-size:18px;font-weight:400;font-family:sans-serif;line-height:1.5;}.controls{margin-top:18px;}button{border:2px solid var(--color-primary,#40ff5e);background:#000;color:var(--color-primary,#40ff5e);padding:10px;font-size:13px;border-radius:12px;}.note,.source{display:block;font-size:11px;margin-top:8px;color:var(--color-text-secondary,rgba(64,255,94,.6));}.source{word-break:break-all;}@media (target:_current){.controls{display:none;}}
</style>
