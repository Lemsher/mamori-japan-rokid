<script def>
{
  "navigationBarTitleText": "まもり",
  "description": "日本の選択した市町村の天気予報と気象警報を取得して表示。市町村が未指定なら場所を確認する。カードは表示専用、操作は全画面で行う。",
  "schema": {"data": {"type":"object","properties": {
    "cityCode":{"type":"string","description":"確認済みの気象庁市町村コード。未確認なら省略。"},
    "lang":{"type":"string","enum":["ja","zh"]}
  }}}
}
</script>
<script setup>
import wx from 'wx';
import { getJSON, warningSummary, isSnapshotFresh, jstTime } from '../../modules/client.js';
import { resolveIntent, classifyIntent } from '../../modules/playbooks.js';
import { JAPANESE_ASR_VERIFIED } from '../../modules/config.js';
export default {
  data: {lang:'ja',cityCode:'',city:'場所を選択',summary:'最新の警報は未確認。',forecast:'',query:'',busy:false,
    choices:[],bulletins:[],message:'',hostTarget:'_blank'},
  onLoad(q = {}) {
    this.setData({lang:q.lang === 'zh' ? 'zh' : 'ja',cityCode:q.cityCode || ''});
    if (q.cityCode) this.refresh();
  },
  onShow() {
    this._hidden=false;
    if (this._snapshot) {
      this.setData({summary:warningSummary(this._snapshot,this.data.lang)});
      if(!isSnapshotFresh(this._snapshot))this.setData({bulletins:[],forecast:'天気予報は再取得してください / 请刷新预报'});
      else this._expiry=setTimeout(()=>this.setData({bulletins:[],summary:warningSummary(this._snapshot,this.data.lang),forecast:'天気予報は再取得してください / 请刷新预报'}),Math.max(0,120000-(Date.now()-Date.parse(this._snapshot.checkedAt))));
    }
  },
  onTargetChanged(target) {this.setData({hostTarget:target});},
  input(e) {this.setData({query:e.detail.value});},
  async chooseCity() {
    try {
      const res = await getJSON('/api/areas');
      const q = this.data.query.trim();
      const choices = q ? res.cities.filter(c=>(c.office+c.name).includes(q) || c.code===q).slice(0,8) : [];
      this.setData({choices,message:choices.length ? '' : '市町村名を入力 / 请输入市町村名'});
    } catch {this.setData({message:'通信未設定・取得失敗 / 未连接服务。離線ガイドは使用可能。'});}
  },
  selectCity(e) {this._request=(this._request||0)+1;this._snapshot=null;this.setData({cityCode:e.currentTarget.dataset.code,city:'場所を確認中 / 正在确认地点',choices:[],busy:false});this.refresh();},
  async refresh() {
    if (this.data.busy || !this.data.cityCode) return;
    const request=this._request=(this._request||0)+1;
    clearTimeout(this._expiry);
    this.setData({busy:true,forecast:'',bulletins:[],summary:'取得中 / 查询中'});
    try {
      const res = await getJSON('/api/snapshot?city='+encodeURIComponent(this.data.cityCode));
      if (this._hidden || request!==this._request) return;
      this._snapshot = res;
      const day = isSnapshotFresh(res) && res.forecast && !res.forecast.stale && res.forecast.days[0];
      const reports=(res.warnings&&res.warnings.reports)||[];
      const latest=reports.slice().sort((a,b)=>Date.parse(b.issuedAt)-Date.parse(a.issuedAt))[0];
      this.setData({city:res.city.office+' '+res.city.name,summary:warningSummary(res,this.data.lang),
        forecast:day ? res.forecast.area+'：'+day.condition+' / 予報発表 '+jstTime(res.forecast.issuedAt) : '天気予報 未確認 / 天气未确认',
        bulletins:isSnapshotFresh(res)?res.national.slice(0,3).map(e=>({...e,time:jstTime(e.issuedAt)})):[],
        message:'取得 '+jstTime(res.checkedAt)+(latest?' / 警報電文 '+jstTime(latest.issuedAt):'')+' / 自治体避難情報は未接続'});
      clearTimeout(this._expiry);
      this._expiry=setTimeout(()=>this.setData({bulletins:[],summary:warningSummary(res,this.data.lang),forecast:'天気予報は再取得してください / 请刷新预报'}),120000);
    } catch {if(request===this._request&&!this._hidden){this._snapshot=null;this.setData({summary:'最新の警報は未確認 / 最新预警未确认',message:'接続先・通信を確認 / 请检查服务配置与网络'});}}
    finally {if(!this._hidden&&request===this._request)this.setData({busy:false});}
  },
  async ask() {
    const quick=classifyIntent(this.data.query);
    if(quick.intent!=='weather'&&quick.intent!=='unknown'){this.openGuide(quick.intent,quick.blocked);return;}
    if (this._asking) return;
    this._asking=true;
    const r=await resolveIntent(this.data.query,typeof LanguageModel === 'undefined' ? null : LanguageModel);
    this._asking=false;
    if(this._hidden)return;
    if(r.intent==='weather'){this.refresh();return;}
    if(r.intent==='unknown'){this.setData({message:'災害名を選択 / 请选择灾害类型'});return;}
    this.openGuide(r.intent,r.blocked);
  },
  openGuide(hazard,blocked=false) {wx.navigateTo({url:'/pages/guide/index?hazard='+hazard+'&lang='+this.data.lang+'&blocked='+blocked});},
  earthquake(){this.openGuide('earthquake');}, tsunami(){this.openGuide('tsunami');},
  landslide(){this.openGuide('landslide');}, flood(){this.openGuide('flood');}, prepare(){this.openGuide('prepare');},
  typhoon(){this.openGuide('typhoon');}, volcano(){this.openGuide('volcano');},
  async listen() {
    if(this._recognition)return;
    if(this.data.lang==='ja' && !JAPANESE_ASR_VERIFIED){this.setData({message:'日本語音声は未検証。文字・ボタンで操作。'});return;}
    if(typeof SpeechRecognition==='undefined'){this.setData({message:'音声入力が利用できません / 语音不可用'});return;}
    const r=new SpeechRecognition();this._recognition=r;
    r.onresult=e=>{const t=e.results[0][0].transcript;this.setData({query:t,message:''});this.ask();};
    r.onerror=()=>this.setData({message:'音声認識失敗 / 语音识别失败'});
    r.onend=()=>{this._recognition=null;};
    this.setData({message:'音声を認識中 / 正在聆听'});
    try{r.start();}catch{this._recognition=null;this.setData({message:'音声入力が利用できません'});}
  },
  onHide(){this._hidden=true;this._request=(this._request||0)+1;clearTimeout(this._expiry);if(this._recognition)this._recognition.abort();this._recognition=null;this.setData({busy:false});},
  onUnload(){this.onHide();}
};
</script>
<page>
  <scroll-view class="panel" scroll-y="true">
    <view class="top"><text class="title">まもり</text><text class="small">JAPAN / 防災支援</text></view>
    <text class="location">{{city}}</text>
    <text class="status">{{summary}}</text>
    <text class="small">{{forecast}}</text>
    <view class="controls">
      <input class="query" maxLength="500" value="{{query}}" placeholder="市町村名 / 災害の状況" bindinput="input" />
      <view class="row"><button bindtap="chooseCity">場所を選ぶ</button><button bindtap="ask">相談</button><button bindtap="listen">音声</button><button bindtap="refresh">更新</button></view>
      <button ink:for="{{choices}}" ink:key="code" data-code="{{item.code}}" bindtap="selectCity">{{item.office}} {{item.name}}</button>
      <view class="row"><button bindtap="earthquake">地震</button><button bindtap="tsunami">津波</button><button bindtap="landslide">土砂</button><button bindtap="flood">洪水</button><button bindtap="prepare">備え</button></view>
      <view class="row"><button bindtap="typhoon">台風</button><button bindtap="volcano">火山</button></view>
    </view>
    <text class="small">{{message}}</text>
    <view ink:if="{{bulletins.length > 0}}">
      <text class="small">全国発表履歴 / 全国通报历史。現地の警報状態ではありません。</text>
      <view ink:for="{{bulletins}}" ink:key="id"><text class="small">{{item.title}} / {{item.time}}</text><text class="small">{{item.summary}}</text></view>
    </view>
    <text class="small">119 救急・救助 / 110 警察</text>
    <text class="inline-hint">操作はダブルタップで全画面へ</text>
  </scroll-view>
</page>
<style>
.panel{width:480px;height:352px;box-sizing:border-box;padding:18px;background:var(--color-background,#000);color:var(--color-text-primary,#40ff5e);border:2px solid var(--color-primary,#40ff5e);border-radius:12px;}
.top,.row{display:flex;flex-direction:row;align-items:center;gap:8px;}.top{justify-content:space-between;}.title{font-size:24px;font-weight:700;font-family:monospace;}.location{display:block;font-size:18px;font-weight:700;margin-top:12px;}.status{display:block;font-size:18px;margin:12px 0;}.small{display:block;font-size:11px;margin-top:6px;color:var(--color-text-secondary,rgba(64,255,94,.6));}
.query{height:54px;margin:0;--input-border-width:0px;--input-padding-x:0px;--input-padding-y:0px;--input-background-color:transparent;}.row{margin:8px 0;}button{font-size:13px;color:var(--color-primary,#40ff5e);border:2px solid var(--color-primary,#40ff5e);background:#000;border-radius:12px;padding:8px;}.inline-hint{display:none;font-size:13px;}
@media (target:_current){.controls{display:none;}.inline-hint{display:block;}}
</style>
